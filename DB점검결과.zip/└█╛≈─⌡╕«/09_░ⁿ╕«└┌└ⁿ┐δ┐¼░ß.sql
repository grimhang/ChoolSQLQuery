EXEC sp_configure 'show advanced options', 1 ;  
GO  
RECONFIGURE  
GO  
EXEC sp_configure 'remote admin connections', 1 ;  
GO  
RECONFIGURE  
GO  