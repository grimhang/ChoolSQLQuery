use master
go

IF OBJECT_ID('sp_whoIs') IS NULL
    EXEC ('CREATE PROC sp_whoIs AS SELECT 1')
GO

ALTER  PROC dbo.sp_whoIs @status varchar(100) = 'active', @IncludeLocalYN CHAR(1) = 'Y', @TYPE TINYINT = 1

/**************************************************************
-- Title        : sp_who2�� Ŀ���� ���� V2.   Ŭ���̾�Ʈ ���� ���̺� TClientConnection ���
-- Author 	    : �ڼ���
-- Create date  : 2022-03-25
-- Description  : ������ ����
    
        DATE         	Developer       Change
        ----------   	--------------- --------------------------
        2019-09-08      �ڼ���         	ó�� �ۼ�
        2019-12-18      �ڼ���          client_net_address ���� <local machine> ���ܷ��� case������ ����

        exec sp_whoIs                        -- default(active sesseion)
        exec sp_whoIs 'all'                  -- all sesseion        
        exec sp_whoIs @IncludeLocalYN = 'N'  -- only not local session
        exec sp_whoIs 'all', 'N'             -- all session, not local
        exec sp_whoIs null, 'N'
**************************************************************/


AS
BEGIN
    DECLARE @statusVar varchar(100) 
    SET @statusVar = @status

    IF @TYPE = 1
    BEGIN

        SELECT C.session_id
            , P.open_tran
            , P.blocked
            , RTRIM(P.loginame) AS LoginName
            , DB_Name(P.dbid) DBName
            --, P.net_address MAC -- ��Ȯġ ����. Ȯ�ο��
            --, rtrim(P.hostname) HostName
            --, ISNULL(CL.HostName, RTRIM(P.hostname)) as Hostname
            , p.cpu AS CPU
            , P.physical_io AS DiskIO
            --, CL.UserName
            --, cl.ClientIP
            , C.client_net_address AS ClientIP
            --, CL.ClientMac    
            , P.net_address ClientMac -- ��Ȯġ ����. Ȯ�ο��
            , RTRIM(
                CASE
                    WHEN P.program_name LIKE 'Microsoft SQL Server Management Studio%' THEN 'SSMS'
                    WHEN P.program_name LIKE 'SQLAgent%' THEN 'SQL Agent'
                    WHEN P.program_name LIKE 'Microsoft JDBC Driver for SQL Server%' THEN 'MS JDBC'
                    ELSE P.program_name
                END) AS ClientApp
            , C.net_transport AS ClientProtocol
            --, CONVERT(varchar(19), C.connect_time, 121 ) ConnTime
			, CONVERT(varchar(19), P.last_batch, 121 ) LastBatchTime
            --,  rtrim(P.lastwaittype) LastWaitType
            , RTRIM(P.status) Status
            , P.cmd    
        FROM sys.dm_exec_connections AS C
            JOIN sys.sysprocesses AS P                        ON C.session_id = P.spid
            --LEFT join master..TClientConnection AS CL       ON CL.ClientIP = C.client_net_address
        WHERE 1 = 1
            AND (
                    (
                        CASE WHEN @IncludeLocalYN = 'Y' THEN 'a' ELSE C.client_net_address END
                        <>
                        CASE WHEN @IncludeLocalYN = 'Y' THEN 'b' ELSE '<local machine>' END
                    )
                )
            AND (
                    (
                        CASE WHEN @statusVar = 'active' THEN RTRIM(P.status)    ELSE 'a' END
                        =
                        CASE WHEN @statusVar = 'active' THEN 'runnable'         ELSE 'a' END
                    )
                    OR 
                    (
                        CASE WHEN @statusVar = 'active' THEN RTRIM(P.status)    ELSE 'a' END
                        =
                        CASE WHEN @statusVar = 'active' THEN 'suspended'        ELSE 'a' END
                    )
                )
        ORDER BY C.session_id

    END
END


EXEC sys.sp_MS_marksystemobject
    'sp_whoIs';   -- skip this for Azure
GO    