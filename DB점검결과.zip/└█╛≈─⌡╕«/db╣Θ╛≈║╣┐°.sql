USE [master]
go

-- �� 5��
backup database lottegrs to disk = 'L:\DBBackup\lottegrs_2023-01-04.bak' with stats = 1, compression
go

-- �� 5��
RESTORE DATABASE [lottegrs_20230104] FROM  DISK = N'L:\DBBackup\lottegrs_2023-01-04.bak' 
    WITH  FILE = 1,  
        MOVE N'lottegrs' TO N'E:\MSSQL15.MSSQLSERVER\MSSQL\DATA\lottegrs_20230104.mdf',  
        MOVE N'lottegrs_log' TO N'E:\MSSQL15.MSSQLSERVER\MSSQL\DATA\lottegrs_20230104_log.ldf',  NOUNLOAD,  STATS = 1
GO


