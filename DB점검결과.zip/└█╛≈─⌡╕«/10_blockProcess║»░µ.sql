EXEC sp_configure 'show advanced options', 1 ;  
GO  
RECONFIGURE  
GO  
EXEC sp_configure 'blocked process threshold', 10 ;  
GO  
RECONFIGURE  
GO  