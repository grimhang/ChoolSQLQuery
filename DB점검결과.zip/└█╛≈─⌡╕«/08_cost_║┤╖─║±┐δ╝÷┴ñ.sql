EXEC sp_configure 'show advanced options', 1 ;  
GO  
RECONFIGURE  
GO  
EXEC sp_configure 'cost threshold for parallelism', 50 ;  
GO  
RECONFIGURE with override
GO  

-- https://docs.aws.amazon.com/prescriptive-guidance/latest/sql-server-ec2-best-practices/parallelism.html