sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO
sp_configure 'max server memory', 60416;  -- 59GB 
GO
RECONFIGURE;
GO

select 59 * 1024